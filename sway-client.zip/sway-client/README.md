# Sway Client (Fabric 1.21.11)
Lightweight utility client. No cosmetics, shop, accounts or custom title screen.

Build (Java 21): `gradle build` -> build/libs/sway-client-1.0.0.jar (needs Fabric API)

Keys: Right Shift = menu, C = zoom (hold), Left Alt = freelook (hold).
Waypoints: /waypoint add <name> | remove <name> | list

Modules (18): FPS, Ping, Saturation, Keystrokes, Mouse Buttons, Potion Timers, Armor Durability,
Armor Bar, Totem Counter, Inventory HUD, Waypoints, Scoreboard, Health Indicator, Low Fire,
Low Shield, Custom Crosshair, Freelook, Zoom.
