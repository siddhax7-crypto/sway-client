package dev.sway;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

public class Waypoints {
    public record WP(String name, int x, int y, int z, String dim) {}
    public static final List<WP> LIST = new ArrayList<>();
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("sway-waypoints.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            List<WP> l = GSON.fromJson(Files.readString(FILE), new TypeToken<List<WP>>() {}.getType());
            if (l != null) LIST.addAll(l);
        } catch (Exception ignored) {}
    }

    public static void save() {
        try { Files.writeString(FILE, GSON.toJson(LIST)); } catch (Exception ignored) {}
    }
}
