package dev.sway;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class SwayClient implements ClientModInitializer {
    public static KeyBinding menuKey, zoomKey, freelookKey;

    @Override
    public void onInitializeClient() {
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of("sway", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.sway.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, cat));
        zoomKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.sway.zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, cat));
        freelookKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.sway.freelook", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_LEFT_ALT, cat));

        Modules.init();
        Config.load();
        Waypoints.load();

        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (menuKey.wasPressed()) c.setScreen(new MenuScreen());
            Modules.tick(c);
        });

        HudElementRegistry.attachElementAfter(VanillaHudElements.MISC_OVERLAYS, Identifier.of("sway", "hud"),
                (ctx, tc) -> Modules.render(ctx));
        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, prev -> (ctx, tc) -> {
            if (Modules.CROSSHAIR.enabled) Modules.drawCrosshair(ctx); else prev.render(ctx, tc);
        });
        HudElementRegistry.replaceElement(VanillaHudElements.SCOREBOARD, prev -> (ctx, tc) -> {
            if (Modules.SCOREBOARD.enabled) prev.render(ctx, tc);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, access) -> dispatcher.register(
                ClientCommandManager.literal("waypoint")
                        .then(ClientCommandManager.literal("add").then(ClientCommandManager.argument("name", StringArgumentType.word())
                                .executes(ctx -> {
                                    MinecraftClient mc = MinecraftClient.getInstance();
                                    if (mc.player == null || mc.world == null) return 0;
                                    String n = StringArgumentType.getString(ctx, "name");
                                    Waypoints.LIST.removeIf(w -> w.name().equalsIgnoreCase(n));
                                    Waypoints.LIST.add(new Waypoints.WP(n, (int) mc.player.getX(), (int) mc.player.getY(),
                                            (int) mc.player.getZ(), mc.world.getRegistryKey().getValue().toString()));
                                    Waypoints.save();
                                    ctx.getSource().sendFeedback(Text.literal("Waypoint added: " + n));
                                    return 1;
                                })))
                        .then(ClientCommandManager.literal("remove").then(ClientCommandManager.argument("name", StringArgumentType.word())
                                .executes(ctx -> {
                                    String n = StringArgumentType.getString(ctx, "name");
                                    boolean ok = Waypoints.LIST.removeIf(w -> w.name().equalsIgnoreCase(n));
                                    Waypoints.save();
                                    ctx.getSource().sendFeedback(Text.literal(ok ? "Removed: " + n : "Not found: " + n));
                                    return 1;
                                })))
                        .then(ClientCommandManager.literal("list").executes(ctx -> {
                            for (Waypoints.WP w : Waypoints.LIST)
                                ctx.getSource().sendFeedback(Text.literal(w.name() + " " + w.x() + " " + w.y() + " " + w.z() + " (" + w.dim() + ")"));
                            return 1;
                        }))));
    }
}
