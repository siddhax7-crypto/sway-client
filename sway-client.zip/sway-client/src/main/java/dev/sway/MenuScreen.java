package dev.sway;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

public class MenuScreen extends Screen {
    public MenuScreen() { super(Text.literal("Sway Client")); }

    @Override
    protected void init() {
        int w = 130, h = 20, gap = 4, cols = 3;
        int x0 = width / 2 - (cols * (w + gap) - gap) / 2, y0 = 40;
        for (int i = 0; i < Modules.ALL.size(); i++) {
            Module m = Modules.ALL.get(i);
            int x = x0 + (i % cols) * (w + gap), y = y0 + (i / cols) * (h + gap);
            addDrawableChild(ButtonWidget.builder(label(m), b -> {
                m.enabled = !m.enabled;
                b.setMessage(label(m));
                Config.save();
            }).dimensions(x, y, w, h).build());
        }
        addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b -> close())
                .dimensions(width / 2 - 50, height - 30, 100, 20).build());
    }

    private static Text label(Module m) { return Text.literal(m.name + ": " + (m.enabled ? "ON" : "OFF")); }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, "Sway Client", width / 2, 20, 0xFFFFFFFF);
    }
}
