package dev.sway;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.util.math.MathHelper;

public final class FreeLook {
    public static boolean active;
    public static float yaw, pitch;
    private static Perspective saved = Perspective.FIRST_PERSON;

    static void update(MinecraftClient c, boolean want) {
        if (c.player == null) { active = false; return; }
        if (want && !active) {
            active = true;
            yaw = c.player.getYaw();
            pitch = c.player.getPitch();
            saved = c.options.getPerspective();
            c.options.setPerspective(Perspective.THIRD_PERSON_BACK);
        } else if (!want && active) {
            active = false;
            c.options.setPerspective(saved);
        }
    }

    public static void turn(double dx, double dy) {
        yaw += (float) dx * 0.15f;
        pitch = MathHelper.clamp(pitch + (float) dy * 0.15f, -90f, 90f);
    }
}
