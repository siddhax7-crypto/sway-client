package dev.sway;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.*;

public final class Modules {
    public interface Renderer { void draw(DrawContext c, int w, int h); }

    public static final List<Module> ALL = new ArrayList<>();
    public static final float ZOOM_FACTOR = 0.25f;
    private static final MinecraftClient MC = MinecraftClient.getInstance();

    public static Module CROSSHAIR, SCOREBOARD, LOW_FIRE, LOW_SHIELD, ZOOM, FREELOOK;

    private static int leftY;
    private static final Deque<Long> lmb = new ArrayDeque<>(), rmb = new ArrayDeque<>();
    private static boolean lDown, rDown;
    private static LivingEntity lastTarget;
    private static long lastTargetTime;

    private static Module add(String n, boolean on) { Module m = new Module(n, on); ALL.add(m); return m; }

    public static void init() {
        // ---- HUD ----
        add("FPS", true).text(() -> MC.getCurrentFps() + " FPS");
        add("Ping", true).text(() -> {
            var h = MC.getNetworkHandler();
            var e = (h == null || MC.player == null) ? null : h.getPlayerListEntry(MC.player.getUuid());
            return (e == null ? 0 : e.getLatency()) + " ms";
        });
        add("Saturation", true).text(() -> MC.player == null ? "" : String.format("Saturation: %.1f",
                MC.player.getHungerManager().getSaturationLevel()));
        add("Keystrokes", true).draw((c, w, h) -> {
            int x = 4, y = leftY + 2;
            key(c, "W", MC.options.forwardKey.isPressed(), x + 22, y, 20);
            key(c, "A", MC.options.leftKey.isPressed(), x, y + 22, 20);
            key(c, "S", MC.options.backKey.isPressed(), x + 22, y + 22, 20);
            key(c, "D", MC.options.rightKey.isPressed(), x + 44, y + 22, 20);
            key(c, "SPACE", MC.options.jumpKey.isPressed(), x, y + 44, 64);
            leftY = y + 68;
        });
        add("Mouse Buttons", true).draw((c, w, h) -> {
            key(c, "LMB " + cps(lmb), lDown, 4, leftY, 48);
            key(c, "RMB " + cps(rmb), rDown, 54, leftY, 48);
            leftY += 24;
        });
        add("Potion Timers", true).draw((c, w, h) -> {
            if (MC.player == null) return;
            for (StatusEffectInstance e : MC.player.getStatusEffects()) {
                int sec = e.getDuration() / 20;
                String s = e.getEffectType().value().getName().getString() + " " + (e.getAmplifier() + 1)
                        + (e.getDuration() < 0 ? "" : " " + sec / 60 + ":" + String.format("%02d", sec % 60));
                c.drawTextWithShadow(MC.textRenderer, s, 4, leftY, 0xFFFFFFFF);
                leftY += 11;
            }
        });
        add("Armor Durability", true).draw((c, w, h) -> {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            int y = h / 2 - 36;
            for (EquipmentSlot s : slots) {
                ItemStack st = MC.player.getEquippedStack(s);
                if (st.isEmpty()) continue;
                c.drawItem(st, w - 22, y);
                if (st.isDamageable()) {
                    String d = String.valueOf(st.getMaxDamage() - st.getDamage());
                    c.drawTextWithShadow(MC.textRenderer, d, w - 24 - MC.textRenderer.getWidth(d), y + 4, 0xFFFFFFFF);
                }
                y += 18;
            }
        });
        add("Armor Bar", true).draw((c, w, h) -> {
            int armor = MC.player.getArmor();
            int x = w / 2 - 31;
            c.fill(x - 1, 3, x + 63, 11, 0x80000000);
            c.fill(x, 4, x + 62 * Math.min(armor, 20) / 20, 10, 0xFF55AAFF);
            String s = String.valueOf(armor);
            c.drawTextWithShadow(MC.textRenderer, s, x + 31 - MC.textRenderer.getWidth(s) / 2, 2, 0xFFFFFFFF);
        });
        add("Totem Counter", true).draw((c, w, h) -> {
            int n = 0;
            var inv = MC.player.getInventory();
            for (int i = 0; i < inv.size(); i++) {
                ItemStack s = inv.getStack(i);
                if (s.isOf(Items.TOTEM_OF_UNDYING)) n += s.getCount();
            }
            c.drawItem(new ItemStack(Items.TOTEM_OF_UNDYING), w - 44, h / 2 + 44);
            c.drawTextWithShadow(MC.textRenderer, "x" + n, w - 24, h / 2 + 48, 0xFFFFFFFF);
        });
        add("Inventory HUD", false).draw((c, w, h) -> {
            int x = w - 166, y = 4;
            c.fill(x - 2, y - 2, x + 164, y + 56, 0x80000000);
            var inv = MC.player.getInventory();
            for (int i = 0; i < 27; i++) {
                ItemStack s = inv.getStack(9 + i);
                int sx = x + (i % 9) * 18, sy = y + (i / 9) * 18;
                c.drawItem(s, sx, sy);
                c.drawStackOverlay(MC.textRenderer, s, sx, sy);
            }
        });
        add("Waypoints", true).draw((c, w, h) -> {
            if (Waypoints.LIST.isEmpty() || MC.world == null) return;
            String dim = MC.world.getRegistryKey().getValue().toString();
            record Row(String s, double d) {}
            List<Row> rows = new ArrayList<>();
            for (Waypoints.WP wp : Waypoints.LIST) {
                if (!wp.dim().equals(dim)) continue;
                double d = Math.sqrt(MC.player.squaredDistanceTo(wp.x() + .5, wp.y(), wp.z() + .5));
                rows.add(new Row(wp.name() + " " + (int) d + "m", d));
            }
            rows.sort(Comparator.comparingDouble(Row::d));
            int y = 62;
            for (int i = 0; i < Math.min(5, rows.size()); i++) {
                String s = rows.get(i).s();
                c.drawTextWithShadow(MC.textRenderer, s, w - 4 - MC.textRenderer.getWidth(s), y, 0xFFFFFFFF);
                y += 11;
            }
        });
        SCOREBOARD = add("Scoreboard", true);

        // ---- PvP ----
        add("Health Indicator", true).draw((c, w, h) -> {
            if (MC.targetedEntity instanceof LivingEntity le) { lastTarget = le; lastTargetTime = System.currentTimeMillis(); }
            if (lastTarget == null || !lastTarget.isAlive() || System.currentTimeMillis() - lastTargetTime > 3000) return;
            String s = lastTarget.getName().getString() + "  " + String.format("%.1f", lastTarget.getHealth() + lastTarget.getAbsorptionAmount()) + " HP";
            c.drawCenteredTextWithShadow(MC.textRenderer, s, w / 2, h / 2 + 14, 0xFFFF5555);
        });
        LOW_FIRE = add("Low Fire", true);
        LOW_SHIELD = add("Low Shield", true);

        // ---- QoL ----
        CROSSHAIR = add("Custom Crosshair", false);
        FREELOOK = add("Freelook", true).tick(c ->
                FreeLook.update(c, Modules.FREELOOK.enabled && SwayClient.freelookKey.isPressed() && c.currentScreen == null));
        ZOOM = add("Zoom", true);
    }

    public static boolean zoomActive() {
        return ZOOM.enabled && SwayClient.zoomKey != null && SwayClient.zoomKey.isPressed() && MC.currentScreen == null;
    }

    private static int cps(Deque<Long> d) {
        long now = System.currentTimeMillis();
        while (!d.isEmpty() && now - d.peekFirst() > 1000) d.pollFirst();
        return d.size();
    }

    public static void tick(MinecraftClient c) {
        if (c.player == null) return;
        long win = c.getWindow().getHandle(), now = System.currentTimeMillis();
        boolean l = GLFW.glfwGetMouseButton(win, 0) == 1, r = GLFW.glfwGetMouseButton(win, 1) == 1;
        if (l && !lDown) lmb.addLast(now);
        if (r && !rDown) rmb.addLast(now);
        lDown = l; rDown = r;
        for (Module m : ALL) if (m.ticker != null) m.ticker.accept(c);
    }

    public static void render(DrawContext ctx) {
        if (MC.player == null || MC.options.hudHidden) return;
        if (MC.currentScreen != null && !(MC.currentScreen instanceof ChatScreen)) return;
        var tr = MC.textRenderer;
        leftY = 4;
        for (Module m : ALL) {
            if (!m.enabled || m.text == null) continue;
            String s = m.text.get();
            ctx.fill(2, leftY - 2, 6 + tr.getWidth(s) + 2, leftY + 10, 0x80000000);
            ctx.drawTextWithShadow(tr, s, 4, leftY, 0xFFFFFFFF);
            leftY += 14;
        }
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        for (Module m : ALL) if (m.enabled && m.renderer != null) m.renderer.draw(ctx, w, h);
    }

    public static void drawCrosshair(DrawContext c) {
        if (MC.currentScreen != null || !MC.options.getPerspective().isFirstPerson()) return;
        int cx = c.getScaledWindowWidth() / 2, cy = c.getScaledWindowHeight() / 2, col = 0xFFFFFFFF;
        c.fill(cx - 1, cy - 7, cx + 1, cy - 3, col);
        c.fill(cx - 1, cy + 3, cx + 1, cy + 7, col);
        c.fill(cx - 7, cy - 1, cx - 3, cy + 1, col);
        c.fill(cx + 3, cy - 1, cx + 7, cy + 1, col);
    }

    private static void key(DrawContext c, String label, boolean down, int x, int y, int w) {
        c.fill(x, y, x + w, y + 20, down ? 0xA0FFFFFF : 0x80000000);
        var tr = MC.textRenderer;
        c.drawTextWithShadow(tr, label, x + (w - tr.getWidth(label)) / 2, y + 6, down ? 0xFF000000 : 0xFFFFFFFF);
    }
}
