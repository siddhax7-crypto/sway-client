package dev.sway;

import com.google.gson.*;
import net.fabricmc.loader.api.FabricLoader;
import java.nio.file.*;
import java.util.*;

public class Config {
    private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("sway.json");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    public static void load() {
        try {
            if (!Files.exists(FILE)) return;
            JsonObject o = JsonParser.parseString(Files.readString(FILE)).getAsJsonObject();
            for (Module m : Modules.ALL) if (o.has(m.name)) m.enabled = o.get(m.name).getAsBoolean();
        } catch (Exception ignored) {}
    }

    public static void save() {
        try {
            Map<String, Boolean> map = new LinkedHashMap<>();
            for (Module m : Modules.ALL) map.put(m.name, m.enabled);
            Files.writeString(FILE, GSON.toJson(map));
        } catch (Exception ignored) {}
    }
}
