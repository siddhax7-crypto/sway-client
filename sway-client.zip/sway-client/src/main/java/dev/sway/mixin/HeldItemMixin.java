package dev.sway.mixin;

import dev.sway.Modules;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.item.HeldItemRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(HeldItemRenderer.class)
public class HeldItemMixin {
    // float args: tickDelta(0), pitch(1), swingProgress(2), equipProgress(3)
    @ModifyVariable(method = "renderFirstPersonItem", at = @At("HEAD"), argsOnly = true, ordinal = 3)
    private float sway$lowShield(float equip) {
        var p = MinecraftClient.getInstance().player;
        if (Modules.LOW_SHIELD.enabled && p != null && p.isBlocking()) return equip + 0.25f;
        return equip;
    }
}
