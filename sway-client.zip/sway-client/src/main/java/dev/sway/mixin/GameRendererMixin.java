package dev.sway.mixin;

import dev.sway.Modules;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(GameRenderer.class)
public class GameRendererMixin {
    @Inject(method = "getFov", at = @At("RETURN"), cancellable = true)
    private void sway$zoom(CallbackInfoReturnable<Float> cir) {
        if (Modules.zoomActive()) cir.setReturnValue(cir.getReturnValue() * Modules.ZOOM_FACTOR);
    }
}
