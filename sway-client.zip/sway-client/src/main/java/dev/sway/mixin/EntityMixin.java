package dev.sway.mixin;

import dev.sway.FreeLook;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Entity.class)
public class EntityMixin {
    @Inject(method = "changeLookDirection", at = @At("HEAD"), cancellable = true)
    private void sway$look(double dx, double dy, CallbackInfo ci) {
        if (FreeLook.active && (Object) this == MinecraftClient.getInstance().player) {
            FreeLook.turn(dx, dy);
            ci.cancel();
        }
    }
}
