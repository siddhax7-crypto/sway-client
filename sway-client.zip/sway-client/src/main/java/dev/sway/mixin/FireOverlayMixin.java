package dev.sway.mixin;

import dev.sway.Modules;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(InGameOverlayRenderer.class)
public class FireOverlayMixin {
    @ModifyVariable(method = "renderFireOverlay", at = @At("HEAD"), argsOnly = true)
    private static MatrixStack sway$lowFire(MatrixStack m) {
        if (Modules.LOW_FIRE.enabled) m.translate(0f, -0.35f, 0f);
        return m;
    }
}
