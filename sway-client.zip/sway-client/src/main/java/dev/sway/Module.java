package dev.sway;

import net.minecraft.client.MinecraftClient;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class Module {
    public final String name;
    public boolean enabled;
    Supplier<String> text;
    Modules.Renderer renderer;
    Consumer<MinecraftClient> ticker;

    Module(String name, boolean enabled) { this.name = name; this.enabled = enabled; }
    Module text(Supplier<String> t) { this.text = t; return this; }
    Module draw(Modules.Renderer r) { this.renderer = r; return this; }
    Module tick(Consumer<MinecraftClient> t) { this.ticker = t; return this; }
}
